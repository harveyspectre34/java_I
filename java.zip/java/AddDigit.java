class AddDigit
{

  public static int digitSum(int num)
  {
     int sum=0;
     while(num>0)
	{
	sum=sum+num%10;
	num=num/10;
	}
return sum;
  }
  public static void main(String[] args)
  {
	if(args.length==0)
	{
	System.out.println("Zero arguments passed");
	}
	else
	{
	for(int i=0;i<args.length;i++)
	{
	    int no=Integer.parseInt(args[i]);
 	    digitSum(no);
	     System.out.println("Sum of digit is: " + digitSum(no));
	}
	}
  }
}