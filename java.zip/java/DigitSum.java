class DigitSum{
public static int dig(int num)
{
	int sum=0;
	while(num>0)
	{
	sum=sum+num%10;
	num=num/10;
	}
	return sum;
}
public static void main(String args[])
{
	
	int ans=0;
	for(int i=0;i<args.length;i++)
	{
	int no=Integer.parseInt(args[i]);
	ans=dig(no);	
	System.out.println("Addition of digits:"+ans);
	}
	
}
}