class MinMax{
public static int findMin(int brr[])
{
	int min=brr[0];
	for(int i=0;i<brr.length;i++)
	{
		if(min<brr[i])
		{	min=brr[i]; }
	}
	return min;
}
public static int findMax(int brr[])
{
	int max=brr[0];
	for(int i=0;i<brr.length;i++)
	{
		if(max>brr[i])
		{	max=brr[i]; }
	}
	return max;
}
public static void main(String[] args)
{
	int arr[]={5,2,6,7};
	int no=arr.length;
	int res=findMin(arr);
	int res1=findMax(arr);
	System.out.println("Min num: "+res+" Max num: "+res1);
}
}