//Find the Row with a Maximum Number of 1’s java

class MatMax{
public static void main(String[]args){
	int mat[][]={{0,1,1,0},{0,0,0,0},{1,0,1,1},{1,1,1,1}};
	int cnt=0;

	int maxCnt=-1;
	int maxRowInd=-1;

	int row=mat.length;
	int col=mat[0].length;

	for(int i=0;i<row;i++)
	{
	for(int j=0;j<col;j++)
	{
		if(mat[i][j]==1)
		{
			cnt++;
		}
	}
	if(maxCnt<cnt)
	{
		maxCnt=cnt;
		maxRowInd=i;
	}
	}
	System.out.println("Max ones row: "+maxRowInd+" Max count: "+maxCnt);
}
}