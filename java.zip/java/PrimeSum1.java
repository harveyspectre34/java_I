class PrimeSum1{
public static boolean isPrime(int no)
{
if(no<=1)
{
return false;
}
	for(int i=2;i<no;i++)
	{
		if(no%i==0 )
		{
			return false;
		}
	}
	return true;
}
public static void main(String[] args)
{
	int sum=0;
	if(args.length==0)
	{
		System.out.println("zero arguments passed");
	}
	else
	{
	for( int i=0;i<args.length;i++)
	{
		int num=Integer.parseInt(args[i]);
		if(isPrime(num))
		{
			sum=sum+num;
		}
	}
System.out.println("sum of prime number is: "+sum);
	}
	
}
}