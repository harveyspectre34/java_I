import java.util.Scanner;
class Add{
public static void main(String []args){
	int sum=0;
	Scanner sc=new Scanner (System.in);
	System.out.println("Enter the numbers:");
	
	for(int i=0;i<5;i++)
	{
		int no=sc.nextInt();
		sum=sum+no;
	}
	System.out.println("Sum is:"+sum);
}
}