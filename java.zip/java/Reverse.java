

class Reverse
{
	public static void reverseNo(int rarr[])
	{
		int rev = rarr.length;
		for(int i=0;i<rev/2;i++)  //Iterate over the first half and for every index i
		{
		int temp=rarr[i];
		rarr[i]=rarr[rev-i-1];
		rarr[rev-i-1]=temp;
		}
	}
	public static void main(String[] args)
	{
		int arr[]={6,4,3,7};
		reverseNo(arr);
		for(int i=0;i<arr.length;i++)
		{
		System.out.println("reverse array is: "+ arr[i]);
		}
	}
}