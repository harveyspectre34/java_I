class PrimeSum{
public static boolean isPrime(int no)
{
	for(int i=2;i<no;i++)
	{
		if(no%i==0)
		{
		return false;
		}
	}
	return true;
}
public static void main(String[] args)
{
	int sum=0;
	for(int i=0;i<args.length;i++)
	{
		int num=Integer.parseInt(args[i]);
		if(isPrime(num))
		{
		sum=sum+num;
		}
		
	}
	System.out.println("Sum of prime number:"+sum);
}
}