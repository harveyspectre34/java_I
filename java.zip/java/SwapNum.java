import java.util.*;
class SwapNum{
public static void swpNo(int a,int b)
{
	int temp=0;
	temp=a;
	a=b;
	b=temp;
	System.out.println("Swapped numbers:"+a+" "+b);
}
public static void main(String[] args)
{
	int num1=0,num2=0;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter two numbers:");
	num1=sc.nextInt();
	num2=sc.nextInt();
	swpNo(num1,num2);
}
}