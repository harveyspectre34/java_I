import java.util.*;

class DiagonalMat{
public static void main(String[] args)
{
	int row=0;
	int col=0;
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter number of rows:");
	row=sc.nextInt();
	System.out.println("Enter number of columns:");
	col=sc.nextInt();

	int mat[][]=new int[row][col];
	
	for(int i=0;i<row;i++)
	{
	for(int j=0;j<col;j++)
	{
		mat[i][j]=sc.nextInt();
	}
	}
	
	for(int i=0;i<row;i++)
	{
	for(int j=0;j<col;j++)
	{
		if(i==j)
		{
			System.out.println(mat[i][j]);
		}
	}
	}
}
}