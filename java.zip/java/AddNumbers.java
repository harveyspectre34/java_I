class AddNumbers{
public static void main(String[] args)
{
	int sum=0;
	if(args.length==0)
	{
	System.out.println("Zero argument passed");
	}
	else
	{
	for(int i=0;i<args.length;i++)
	{
		int no=Integer.parseInt(args[i]);
		if(no%3==0 || no%5==0 || no%11==0)
		{
			sum=sum+no;
		}
	}
	System.out.println("Sum of numbers is:"+sum);
	}
	
}
}