//Find the Row with a Maximum Number of 1’s java
import java.util.*;

class MatMaxUser{
public static void main(String[]args){
	int cnt=0;

	int maxCnt=0;  //max count of 1's initialized to -1
	int maxRowInd=0;   //max 1's in a row

	Scanner sc=new Scanner(System.in);

	System.out.println("Enter number of rows:");
	int row=sc.nextInt();
	System.out.println("Enter number of columns:");
	int col=sc.nextInt();	

	int mat[][]=new int[row][col];  //initialize matrix row and column value
	
	System.out.println("Enter values in the matrix:");
	for(int i=0;i<row;i++)
	{
	for(int j=0;j<col;j++)
	{
		mat[i][j]=sc.nextInt(); //accepting and storing values
	}
	}

	for(int i=0;i<row;i++)
	{
	for(int j=0;j<col;j++)
	{
		if(mat[i][j]==1)
		{
			cnt++;  //count of 1's
		}
	}
	if(maxCnt<cnt)
	{
		maxCnt=cnt;    //max count of 1's in row
		maxRowInd=i;   //row number
	}
	}
	System.out.println("Max ones row: "+maxRowInd+" Max count: "+maxCnt);
}
}