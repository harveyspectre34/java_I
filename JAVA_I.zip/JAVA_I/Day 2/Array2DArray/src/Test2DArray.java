
public class Test2DArray {
	public static void main(String[] args) {
		int[][] arr=new int[5][3];
		Array2DService.acceptData(arr);
		Array2DService.displayData(arr);
		
	}

}
