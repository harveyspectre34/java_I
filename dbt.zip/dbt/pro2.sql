
/*
DELIMITER $

CREATE TRIGGER insertStudent
AFTER INSERT ON STUDENT
FOR EACH ROW
BEGIN
    INSERT INTO LOG (log_date, log_time, message)
    VALUES (CURDATE(), CURTIME(), 'Record inserted successfully');
END $

DELIMITER ;
*/

delimiter $ 
create trigger insertStudent
after insert on student
for each row
begin
 insert into lo(log_date,log_time,message)
values (CURDATE(),CURTIME(),'Record inserted sucessfully');
end $
 delimiter;